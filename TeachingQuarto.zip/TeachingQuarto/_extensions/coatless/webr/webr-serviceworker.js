importScripts('https://webr.r-wasm.org/v0.2.2/webr-serviceworker.js');
